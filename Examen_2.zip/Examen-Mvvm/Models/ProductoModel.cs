namespace Examen_Mvvm.Models
{
    public class ProductoModel
    {
        public double Producto1 { get; set; }
        public double Producto2 { get; set; }
        public double Producto3 { get; set; }
    }
}