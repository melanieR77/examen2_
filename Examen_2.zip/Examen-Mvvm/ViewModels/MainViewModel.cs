using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;

namespace Examen_Mvvm.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        [ObservableProperty] private string producto1;
        [ObservableProperty] private string producto2;
        [ObservableProperty] private string producto3;

        [ObservableProperty] private double subtotal;
        [ObservableProperty] private double descuento;
        [ObservableProperty] private double total;

        [RelayCommand]
        private void Calcular()
        {
            try
            {
                double p1 = double.Parse(Producto1);
                double p2 = double.Parse(Producto2);
                double p3 = double.Parse(Producto3);

                Subtotal = p1 + p2 + p3;

                if (Subtotal >= 10000)
                    Descuento = Subtotal * 0.30;
                else if (Subtotal >= 5000)
                    Descuento = Subtotal * 0.20;
                else if (Subtotal >= 1000)
                    Descuento = Subtotal * 0.10;
                else
                    Descuento = 0;

                Total = Subtotal - Descuento;
            }
            catch
            {
                App.Current.MainPage.DisplayAlert("Error", "Por favor ingrese solo números válidos.", "OK");
            }
        }

        [RelayCommand]
        private void Limpiar()
        {
            Producto1 = Producto2 = Producto3 = string.Empty;
            Subtotal = Descuento = Total = 0;
        }
    }
}