using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace AreaCirculoV2App.ViewModels;

public partial class AreaRectanguloViewModel : ObservableObject
{
    [ObservableProperty]
    private string @base;

    [ObservableProperty]
    private string altura;

    [ObservableProperty]
    private string resultado;

    [RelayCommand]
    private void Calcular()
    {
        if (double.TryParse(Base, out double b) && double.TryParse(Altura, out double h) && b > 0 && h > 0)
        {
            Resultado = $"Área del rectángulo: {b * h}";
        }
        else
        {
            Resultado = "Valores inválidos.";
        }
    }

    [RelayCommand]
    private void Limpiar()
    {
        Base = string.Empty;
        Altura = string.Empty;
        Resultado = string.Empty;
    }
}