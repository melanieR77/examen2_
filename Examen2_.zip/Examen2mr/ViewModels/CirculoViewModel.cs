using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;

namespace AreaCirculoV2App.ViewModels;

public partial class CirculoViewModel : ObservableObject
{
    [ObservableProperty]
    private string radioUsuario;

    [ObservableProperty]
    private string areaResultado;

    [RelayCommand]
    private void CalcularArea()
    {
        if (string.IsNullOrWhiteSpace(RadioUsuario))
        {
            AreaResultado = "El campo no puede estar vacío.";
            return;
        }

        if (double.TryParse(RadioUsuario, out double r) && r > 0)
        {
            AreaResultado = $"Área calculada: {Math.PI * r * r:F3}";
        }
        else
        {
            AreaResultado = "Error: Ingrese un número válido.";
        }
    }

    [RelayCommand]
    private void LimpiarTodo()
    {
        RadioUsuario = string.Empty;
        AreaResultado = string.Empty;
    }
}