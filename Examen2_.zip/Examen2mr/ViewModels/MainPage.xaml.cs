using AreaCirculoV2App.ViewModels;

namespace AreaCirculoV2App;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
        BindingContext = new CirculoViewModel();
    }
}