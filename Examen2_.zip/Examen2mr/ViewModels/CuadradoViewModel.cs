using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace AreaCirculoV2App.ViewModels;

public partial class CuadradoViewModel : ObservableObject
{
    [ObservableProperty]
    private string lado;

    [ObservableProperty]
    private string resultado;

    [RelayCommand]
    private void Calcular()
    {
        if (double.TryParse(Lado, out double l) && l > 0)
        {
            Resultado = $"Área del cuadrado: {l * l:F2}";
        }
        else
        {
            Resultado = "Ingrese un número válido.";
        }
    }

    [RelayCommand]
    private void Limpiar()
    {
        Lado = string.Empty;
        Resultado = string.Empty;
    }
}